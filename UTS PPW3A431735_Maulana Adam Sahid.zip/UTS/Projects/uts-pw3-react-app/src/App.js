import logo from './logo.svg';
import './App.css';
import Blog from "./Blog";

function App() {
  return (
    <div className="App">
      <Blog/>
    </div>
  );
}

export default App;
